import { useDispatch, useSelector } from "react-redux"
import { BiSolidChevronsRight } from "react-icons/bi";
import { NavLink, useNavigate } from "react-router-dom";
import { singleGetProduct } from "../../services/actions/product.action";
import { useState } from "react";

export default function CategoryWiseProducts({ list }) {
  const { products } = useSelector(state => state.productReducer);
  var count = 0
  const navigate = useNavigate()
  const dispatch = useDispatch();
  const handleProduct = async (id) => {
    await dispatch(singleGetProduct(id));
    navigate('/productdetailspage')
  }

  const handleRedirect = (i) =>{
    navigate('/productspage', { state: { data: i } })
  }

  return (
    <div className="bg-white pb-12">
      {
        list.map((item) => {
          var count = 0
          return (<div key={item} className="mx-auto max-w-2xl px-4 pt-12 sm:px-6 sm:pt-12 lg:max-w-7xl lg:px-8">
            <div className="flex items-end justify-between">
              <h2 className="text-2xl font-bold tracking-tight text-gray-900">{item}s</h2>
              <a className="font-semibold text-md flex items-center point" onClick={()=>{handleRedirect(item)}}>View More <BiSolidChevronsRight className="ms-1 text-xl font-gray-100" /></a>
            </div>
            <div className="mt-4 grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
              {products.map((product, index) => (
                product.category == item && count < 4 ?(
                  <div key={product.id} onClick={() => {
                    handleProduct(product.id)
                  }} className="group relative ">
                    <span className="hidden">{count++}</span> 
                    <div className="aspect-h-1 aspect-w-1 w-full overflow-hidden rounded-md bg-gray-200 lg:aspect-none group-hover:opacity-75 sm:h-80">
                      <img
                        src={product.thumbnail}
                        alt={product.category}
                        className="h-full w-full object-cover border-2 rounded-md object-top lg:h-full lg:w-full"
                      />
                    </div>
                    <div className="mt-4 flex flex-col">
                      <div>
                        <h3 className="text-sm text-gray-700 font-medium">
                          
                          <span aria-hidden="true" className="absolute inset-0" />
                          <p className="truncate">
                            {product.name}
                          </p>

                        </h3>
                        <p className="mt-1 text-sm text-gray-500 font-bold">{product.color}</p>
                      </div>
                      <p className="text-xl font-medium text-gray-900">Rs.{product.price}</p>
                    </div>
                  </div>
                ) : (<span className="hidden" key={product.id}></span>)
              )

              )}
            </div>
          </div>)
        })
      }

    </div>
  )
}
