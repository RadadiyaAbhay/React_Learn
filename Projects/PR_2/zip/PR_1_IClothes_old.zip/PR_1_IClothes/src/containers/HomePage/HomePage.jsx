import React, { useEffect } from 'react'
import Banner from '../../components/Banner/Banner'
import Collection from '../../components/Collection/Collection'
// import LatestProduct from '../../components/LatestProduct/LatestProduct'
import MostViewed from '../../components/MostViewed/MostViewed'
import { getProducts } from '../../services/actions/product.action'
import { useDispatch } from 'react-redux'
import Achievement from '../../components/Achievement/Achievement'
import CategoryWiseProducts from '../../components/CategoryWiseProducts/CategoryWiseProducts'

function HomePage() {
  const dispatch = useDispatch();
  const category = ['T-shirt' , 'Shirt' ,'Hoodie' , 'Trouser']
  useEffect(()=>{
    dispatch(getProducts());
  } ,[])
  return (
    <>    
    <Banner/>
    <MostViewed/>
    <Collection/>
    <CategoryWiseProducts list={category}/>
    <Achievement/>
    </>
  )
}

export default HomePage