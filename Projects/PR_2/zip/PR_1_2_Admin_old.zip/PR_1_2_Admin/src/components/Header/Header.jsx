import React from 'react'
import { Dropdown, Form, InputGroup } from 'react-bootstrap'
import { PersonCircle, Search } from 'react-bootstrap-icons'
import { useDispatch, useSelector } from 'react-redux'
import { NavLink, useNavigate } from 'react-router-dom'
import { signOutAction } from '../../services/actions/admin.action'

function Header() {
    const navigate = useNavigate();

    const dispatch = useDispatch()
    const handleSignOut = async () =>{
       await dispatch(signOutAction())
        navigate('/dashboard');
    }
    return (
        <>
            <header className='bg-dark py-2 d-flex align-items-center position-sticky top-0 z-2 border-bottom border-secondary border-2'>
                <h2 className='text-white fw-bold m-0 col-2 ps-4'>
                    <NavLink to={'/dashboard'} className='text-white fw-bold text-decoration-none'>
                        Admin
                    </NavLink>
                </h2>
                <div className="col-8 d-flex justify-content-center">
                    <div className='col-5'>
                        <InputGroup>
                            <Form.Control
                                placeholder="Search"
                                aria-label="Recipient's username"
                                aria-describedby="basic-addon2"
                            />
                            <InputGroup.Text id="basic-addon2"><Search /></InputGroup.Text>
                        </InputGroup>
                    </div>
                </div>
                <div className="col-2 d-flex justify-content-end align-items-center text-end pe-4">
                    <PersonCircle className='text-white pe-1 fs-3 point' />
                    <Dropdown>
                        <Dropdown.Toggle variant='dark' className='bg-transparent border-0'>
                        </Dropdown.Toggle>

                        <Dropdown.Menu variant='dark' className='z-1'>
                            <Dropdown.Item href="#" className='btn-dark btn'>Your Profile</Dropdown.Item>
                            <Dropdown.Item onClick={() => { handleEdit(product.id) }} className='pb-2 btn-dark btn'>Settings</Dropdown.Item>
                            <Dropdown.Item onClick={handleSignOut} className='border-top text-danger border-danger btn-dark btn'>Sign Out</Dropdown.Item>
                        </Dropdown.Menu>
                    </Dropdown>
                </div>
            </header>
        </>
    )
}

export default Header