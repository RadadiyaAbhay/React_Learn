import React, { useState } from 'react'
import { useDispatch } from 'react-redux';
import { createUsers } from '../../services/actions/user.action';
import { Button, Container, FloatingLabel, Form, Row } from 'react-bootstrap';
import { useNavigate } from 'react-router';
import { NavLink } from 'react-router-dom';

function CreateUser() {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [user, setUser] = useState({
        name: '',
        address: '',
        email: '',
        phoneNumber: '',
        imgUrl: ''
    })
    const handleInput = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value })
    }
    const handleInput2 = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value })
        const proThumb = document.getElementById('prothumb')
        proThumb.classList.remove('d-none')
    }

    const handleClick = (e) => {
        e.preventDefault();
        dispatch(createUsers(user))
        navigate('/users')
    }
    console.log("CreateUser", user);

    return (
        <>
            <Container className='pt-5'>
                <Row>
                    <Form onSubmit={handleClick}>
                        <div>
                            <FloatingLabel controlId="floatingInput1" label="Name" className="mb-3 bg-transparent text-black">
                                <Form.Control className='bg-transparent text-black' type="text" placeholder="Enter name" name='name' value={user.name} onChange={handleInput} />
                            </FloatingLabel>
                            <FloatingLabel controlId="floatingInput2" label="Address" className="mb-3 bg-transparent text-black">
                                <Form.Control as="textarea" className='bg-transparent text-black' placeholder="Enter Address" name='address' value={user.address} onChange={handleInput} />
                            </FloatingLabel>

                            <div className="d-flex">

                                <div className='col-6 pe-2'>
                                    <FloatingLabel controlId="floatingInput7" label="Email" className="mb-3 bg-transparent text-black">
                                        <Form.Control type="email" className='bg-transparent text-black' min={0} max={5} placeholder="Enter Email" value={user.email} name='email' onChange={handleInput} />
                                    </FloatingLabel>
                                </div>
                                <div className="col-6 ps-2">
                                    <FloatingLabel controlId="floatingInput8" label="Mobile Number" className="mb-3 bg-transparent text-black">
                                        <Form.Control type="number" className='bg-transparent text-black' min={0} placeholder="Enter phone number" value={user.phoneNumber} name='phoneNumber' onChange={handleInput} />
                                    </FloatingLabel>
                                </div>
                            </div>
                            <div className="d-flex">
                                <div className='col-6 pe-2'>

                                    <FloatingLabel controlId="floatingInput5" label="Your Img Url" className="mb-3 bg-transparent text-black">
                                        <Form.Control type="text" className='bg-transparent text-black' placeholder="Enter imgUrl" value={user.imgUrl} name='imgUrl' onChange={handleInput2} />
                                    </FloatingLabel>
                                    <Button variant="dark" type='submit'>Submit</Button>{' '}
                                    <NavLink className='btn btn-dark' to={'/'}>Back</NavLink>
                                </div>
                                <div className="col-6 ps-2 d-none" id='prothumb'>
                                    <img src={user.imgUrl} alt="" className='img-thumbnail col-2' />
                                </div>
                            </div>
                        </div>
                    </Form>

                </Row>
            </Container>
        </>
    )
}

export default CreateUser