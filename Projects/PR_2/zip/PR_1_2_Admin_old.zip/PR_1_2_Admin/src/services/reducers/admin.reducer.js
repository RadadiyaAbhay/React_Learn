import { ADMINLOGINREJ, ADMINLOGINREQ, ADMINLOGINRES, SIGNOUTREJ, SIGNOUTREQ, SIGNOUTRES } from "../const";

const initialState = {
    err: null,
    isLoading: false,
    isLogin: false,
    user: null
}
export const adminReducer = (state = initialState, action) => {
    switch (action.type) {
        case ADMINLOGINREQ:
            return {
                ...state,
                isLoading: true,
                err: null
            }
        case ADMINLOGINRES:
            return {
                ...state,
                isLoading: false,
                isLogin: true,
                user: action.payload,
                err: null
            }
        case ADMINLOGINREJ:
            return {
                ...state,
                isLoading: false,
                isLogin: false,
                err: action.payload,
                user: null
            }
        case SIGNOUTREQ:
            return {
                ...state,
                isLoading: true
            }
        case SIGNOUTRES:
            return {
                ...state,
                isLoading: false,
                err: null,
                isLogin: false,
                user: null
            }
        case SIGNOUTREJ:
            return {
                ...state,
                isLoading: false,
                err: action.payload
            }
        default:
            return state;
    }
}    