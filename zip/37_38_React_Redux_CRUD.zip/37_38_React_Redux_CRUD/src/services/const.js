export const CREATEEMP = "CREATEEMP";
export const DELETEEEMP = "DELETEEEMP";
export const EDITEEMP = "EDITEEMP";
export const NEWEDITEEMP = "NEWEDITEEMP";
export const GETDATA = "GETDATA";