import Product from './components/Product/Product';
import './App.css'

function App() {


  return (
    <>
      <Product/>
    </>
  )
}

export default App;
