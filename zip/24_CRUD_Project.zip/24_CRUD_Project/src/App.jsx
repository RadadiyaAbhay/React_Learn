import React from 'react'
import CRUD from './components/CRUD/CRUD'

function App() {
  return (
    <>
      <CRUD/>
    </>
  )
}

export default App
