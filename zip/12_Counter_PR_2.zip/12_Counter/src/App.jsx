import Counter from './components/Counter/Counter'
import './App.css'

function App() {
  

  return (
    <>
     <Counter/>
    </>
  )
}

export default App
