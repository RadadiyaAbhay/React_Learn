import './Button.css'

function Button() {

    return (
        <>
            <div className='logo col-3 d-flex justify-content-end'>
                <button type='submit'>
                    Login
                </button>
            </div>
        </>
    )
}

export default Button;