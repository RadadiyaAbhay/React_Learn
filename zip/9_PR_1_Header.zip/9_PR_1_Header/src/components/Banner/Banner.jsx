import './Banner.css'

function Banner() {

    return (
        <>
            <section className='backImg'>
                <div className="container">
                    <div className="row ">
                        <h1 className='bann col-12'>
                            Hello Everyone
                        </h1>
                    </div>
                </div>
            </section>
        </>
    )
}

export default Banner;