import React from 'react'

function ReservationImg() {
    return (
        <>
            <section className="bb33">

            </section>
        </>
    )
}

export default ReservationImg
