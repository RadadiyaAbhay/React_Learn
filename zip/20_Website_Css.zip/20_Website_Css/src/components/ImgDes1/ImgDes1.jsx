import React from 'react'
import I98 from '../../assets/98.jpg';
import I97 from '../../assets/97.jpg';


function ImgDes1() {
  return (
    <>
            <section className="py-5 b311 position-relative">
		<div className="position-absolute col-lg-6 col-12 col-sm-12 " style={{top:"0%", left:"-5%", zIndex:"-1"}} >
		     <img src={I98} width="75%"  alt="61"/>
		    </div>
		  <div className="container">
		    <div className="row">
			  <div className="col-lg-6 col-12 col-sm-12 pe-5 our-1"><img src={I97} alt="97" className="img-fluid"/></div>
			  <div className="col-lg-6 col-12 col-sm-12">
			    <h2 className="text-white fw-bolder ps-3 pb-4 pt-5"  style={{fontSize:"45px"}}>The Perfect Patty</h2>
				<p className="text-white pb-5 ps-3">Effortless comfortable full leather lining. Effortless comfortable full leather lining eye-catching unique detail</p>
				<div className="px-3 pb-1">
				    <div className="d-flex justify-content-between dropdowns position-relative">
						<div className="position-absolute dropdown  end-100 d-flex flex-wrap">
							<div className="dropdown bg-white p-4 rounded position-absolute" style={{right: "12px"}}>
								<div className="position-relative">
								  <h4 className="fw-bolder fs-6"> MENU INFORMATION</h4>
								  <ul className="">
								   <li>
									<b>Calories</b> 480
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								  </ul>
								  <p>* 2,000 calories a day is used for general nutrition advice, but calorie needs vary.</p>
							   </div>
							</div>
							<div className="text-white position-absolute" style={{top:"156px", right:"0%"}}>
								<i className="bi bi-caret-right-fill"></i>
							</div>
						</div>

				    <h6 className="text-primary fw-bolder" style={{fontSize:"24px"}}>
					  Spicy Crab Ramen
					</h6>
					<span className="fw-bolder text-primary" style={{fontSize:"22px"}}>$20.0</span>
				    </div>
                    <p className="text-white pb-2">
					 Crab / Veggie / Soup
					</p>
				 </div>
				 <div className="px-3 pb-1">
				    <div className="d-flex justify-content-between position-relative dropdowns">
						<div className="position-absolute dropdown  end-100 d-flex flex-wrap">
							<div className="dropdown bg-white p-4 rounded position-absolute" style={{right: "12px"}}>
								<div className="position-relative">
								  <h4 className="fw-bolder fs-6"> MENU INFORMATION</h4>
								  <ul className="">
								   <li>
									<b>Calories</b> 480
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								  </ul>
								  <p>* 2,000 calories a day is used for general nutrition advice, but calorie needs vary.</p>
							   </div>
							</div>
							<div className="text-white position-absolute" style={{top:"156px", right:"0%"}}>
								<i className="bi bi-caret-right-fill"></i>
							</div>
						</div>

				    <h6 className="text-primary fw-bolder" style={{fontSize:"24px"}}>
					Grilled Salmon Sushi
					</h6>
					<span className="fw-bolder text-primary" style={{fontSize:"22px"}}>$15.5</span>
				    </div>
                    <p className="text-white pb-2">
					 Rice / Salmon / Shoyu
					</p>
				 </div>
				 <div className="px-3 pb-1">
				    <div className="d-flex justify-content-between position-relative dropdowns">
						<div className="position-absolute dropdown  end-100 d-flex flex-wrap">
							<div className="dropdown bg-white p-4 rounded position-absolute" style={{right: "12px"}}>
								<div className="position-relative">
								  <h4 className="fw-bolder fs-6"> MENU INFORMATION</h4>
								  <ul className="">
								   <li>
									<b>Calories</b> 480
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								  </ul>
								  <p>* 2,000 calories a day is used for general nutrition advice, but calorie needs vary.</p>
							   </div>
							</div>
							<div className="text-white position-absolute" style={{top:"156px", right:"0%"}}>
								<i className="bi bi-caret-right-fill"></i>
							</div>
						</div>

				    <h6 className="text-primary fw-bolder" style={{fontSize:"24px"}}>
					  Spicy Crab Ramen
					</h6>
					<span className="fw-bolder text-primary" style={{fontSize:"22px"}}>$20.0</span>
				    </div>
                    <p className="text-white pb-2">
					 Crab / Veggie / Soup
					</p>
				 </div>
				 <div className="border bg-primary text-white fw-bolder rounded-top ps-3 py-1" style={{fontSize:"22px"}}>New</div>
				  <div className="border rounded-bottom px-3 pt-3 pb-1 mb-3">
				    <div className="d-flex justify-content-between position-relative dropdowns">
						<div className="position-absolute dropdown  end-100 d-flex flex-wrap">
							<div className="dropdown bg-white p-4 rounded position-absolute" style={{right: "12px"}}>
								<div className="position-relative">
								  <h4 className="fw-bolder fs-6"> MENU INFORMATION</h4>
								  <ul className="">
								   <li>
									<b>Calories</b> 480
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								   <li>
									 <b>Calories</b> 20g
								   </li>
								  </ul>
								  <p>* 2,000 calories a day is used for general nutrition advice, but calorie needs vary.</p>
							   </div>
							</div>
							<div className="text-white position-absolute" style={{top:"156px", right:"0%"}}>
								<i className="bi bi-caret-right-fill"></i>
							</div>
						</div>

				    <h6 className="text-primary fw-bolder" style={{fontSize:"24px"}}>
					   Fried Chicken Salad
					</h6>
					<span className="fw-bolder text-primary" style={{fontSize:"22px"}}>$12.0</span>
				  </div>
                    <p className="text-white">
					  Chicken / Butter / Veggies
					</p>
				  </div>
				 
			  </div>
			</div>
		  </div>
		</section>
    </>
  )
}

export default ImgDes1
