import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import HomePage from './containers/HomePage/HomePage';
import Header from './components/Header/Header';
import Footer from './components/Footer/Footer';
import AboutPage from './containers/AboutPage/AboutPage';
import ContactPage from './containers/ContactPage/ContactPage';
import OurMenusPage from './containers/OurMenusPage/OurMenusPage';
import ReservationPage from './containers/ReservationPage/ReservationPage';
import Option from './components/Option/Option';

function App() {

  return (
    <>
      <Header/>
      <Option/>
      <HomePage/>
      {/* <AboutPage/> */}
      {/* <ContactPage/> */}
      {/* <ReservationPage/> */}
      {/* <OurMenusPage/> */}
      <Footer/>
    </>
  )
}

export default App
